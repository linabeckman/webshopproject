<?php get_header(); ?>
<?php get_template_part('homepage'); ?>
<?php get_footer(); ?>
