	<section id="main">
			<ul id="gallery">
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</a>
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
								<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
				<li>
					<div class="inner">
						<img src="<?php echo get_template_directory_uri(). '/img/e.png';?>" />
					</div>
				</li>
			</ul>
	</section>