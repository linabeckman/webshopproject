	<section id="main"  class="clearfix">
		<h1>Product</h1>
		<section  class="clearfix">
			<img src="<?php echo (get_template_directory_uri(). 'img/exemple.jpg';?>" id="product"/>
			<aside id="productinfo">
				<p>Info about the product</p>
			</aside>
		</section>
		<h1>More of intrest:</h1>
		<ul id="tipgallery">
			<li>
				<div class="inner">
					<a href="<?php echo (get_template_directory_uri(). 'product.html';?>">
						<img src="<?php echo (get_template_directory_uri(). 'img/exemple.jpg';?>">
					</a>
				</div>
			</li>
			<li>
				<div class="inner">
					<img src="<?php echo (get_template_directory_uri(). 'img/exemple.jpg';?>">
				</div>
			</li>
			<li>
				<div class="inner">
					<img src="<?php echo (get_template_directory_uri(). 'img/exemple.jpg';?>">
				</div>
			</li>
		</ul>
	</section>