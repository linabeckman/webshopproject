<?php get_header(); ?> 
<?php get_template_part('gallery');?>
<?php get_footer();?>