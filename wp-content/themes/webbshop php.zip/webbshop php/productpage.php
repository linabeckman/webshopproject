<?php get_header(); ?>
<?php get_template_part('product');?>
<?php get_footer();?>